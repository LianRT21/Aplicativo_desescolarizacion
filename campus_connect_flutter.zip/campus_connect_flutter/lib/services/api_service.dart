import 'dart:convert';

import 'package:campus_connect_flutter/models/risk_report.dart';
import 'package:http/http.dart' as http;

class ApiConfig {
  static const String baseUrl = 'http://localhost:8000';
  static const String loginPath = '/api/v1/auth/login';
  static const String dashboardPath = '/api/v1/dashboard';
  static const String riskPath = '/api/v1/risk/evaluate';
}

class ApiService {
  static Future<Map<String, dynamic>> login(String username, String password) async {
    final response = await http.post(
      Uri.parse('${ApiConfig.baseUrl}${ApiConfig.loginPath}'),
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: {'username': username, 'password': password},
    );

    if (response.statusCode != 200) {
      throw Exception('Login falló: ${response.body}');
    }

    return jsonDecode(response.body) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> getDashboard(String token) async {
    final response = await http.get(
      Uri.parse('${ApiConfig.baseUrl}${ApiConfig.dashboardPath}'),
      headers: {'Authorization': 'Bearer $token'},
    );

    if (response.statusCode != 200) {
      throw Exception('No se pudo cargar el dashboard');
    }

    return jsonDecode(response.body) as Map<String, dynamic>;
  }

  static Future<RiskReport> evaluateRisk(Map<String, dynamic> payload, String token) async {
    final response = await http.post(
      Uri.parse('${ApiConfig.baseUrl}${ApiConfig.riskPath}'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode(payload),
    );

    if (response.statusCode != 200) {
      throw Exception('La evaluación no pudo completarse');
    }

    return RiskReport.fromJson(jsonDecode(response.body) as Map<String, dynamic>);
  }
}
