import 'package:flutter/material.dart';

class StudentDetailScreen extends StatelessWidget {
  final Map<String, dynamic> student;

  const StudentDetailScreen({super.key, required this.student});

  Color _riskColor(String risk) {
    switch (risk) {
      case 'ROJO':
        return Colors.red;
      case 'AMARILLO':
        return Colors.orange;
      case 'VERDE':
      default:
        return Colors.green;
    }
  }

  @override
  Widget build(BuildContext context) {
    final risk = student['riskLevel'] ?? 'VERDE';
    final score = student['score'] ?? 0;

    return Scaffold(
      appBar: AppBar(
        title: Text(student['name'] ?? 'Estudiante'),
        backgroundColor: const Color(0xFF2F59D9),
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        CircleAvatar(
                          radius: 34,
                          backgroundColor: const Color(0xFF2F59D9),
                          child: Text(
                            (student['name'] ?? 'E').substring(0, 1).toUpperCase(),
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 24,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                student['name'] ?? 'Estudiante',
                                style: const TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              Text('${student['grade'] ?? 'Sin curso'} · ${student['attendance'] ?? 0}% asistencia'),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 18),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        color: _riskColor(risk).withOpacity(0.12),
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        'Riesgo $risk',
                        style: TextStyle(
                          color: _riskColor(risk),
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            _MetricRow(title: 'Puntaje total', value: '$score/100'),
            _MetricRow(title: 'Promedio académico', value: '${student['average'] ?? 0.0}'),
            _MetricRow(title: 'Alertas', value: '${student['alerts'] ?? 0}'),
            const SizedBox(height: 20),
            const Text(
              'Observaciones principales',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 12),
            Text(student['summary'] ?? 'Sin observaciones destacadas por el momento.'),
          ],
        ),
      ),
    );
  }
}

class _MetricRow extends StatelessWidget {
  final String title;
  final String value;

  const _MetricRow({required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w600))),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}
