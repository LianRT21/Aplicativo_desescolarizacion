import 'package:campus_connect_flutter/models/risk_report.dart';
import 'package:campus_connect_flutter/models/user.dart';
import 'package:campus_connect_flutter/screens/student_detail_screen.dart';
import 'package:campus_connect_flutter/services/api_service.dart';
import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  final AppUser user;
  final String token;

  const HomeScreen({super.key, required this.user, required this.token});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<Map<String, dynamic>> _dashboardFuture;
  late Future<RiskReport> _riskFuture;

  final List<Map<String, dynamic>> _students = [
    {
      'name': 'Ana Gómez',
      'grade': '11A',
      'attendance': 62,
      'average': 2.8,
      'alerts': 3,
      'summary': 'Falta acompañamiento familiar y baja asistencia durante la última semana.',
      'riskLevel': 'ROJO',
      'score': 82,
    },
    {
      'name': 'Mateo Ruiz',
      'grade': '10B',
      'attendance': 78,
      'average': 3.4,
      'alerts': 2,
      'summary': 'Presenta riesgo moderado por rendimiento académico y bajada de participación.',
      'riskLevel': 'AMARILLO',
      'score': 61,
    },
    {
      'name': 'Sofía Torres',
      'grade': '9C',
      'attendance': 91,
      'average': 4.1,
      'alerts': 1,
      'summary': 'Estudiante estable con buena asistencia y seguimiento del tutor.',
      'riskLevel': 'VERDE',
      'score': 26,
    },
  ];

  Future<Map<String, dynamic>> _loadDashboard() async {
    try {
      return await ApiService.getDashboard(widget.token);
    } catch (_) {
      return {
        'total_students': 3,
        'active_students': 2,
      };
    }
  }

  Future<RiskReport> _loadRisk() async {
    try {
      return await ApiService.evaluateRisk(
        {
          'id': 'stu-001',
          'full_name': 'Ana Gómez',
          'document_number': '1012345678',
          'grade': '11A',
          'status': 'ACTIVE',
          'attendance_records': [
            {'student_id': 'stu-001', 'date': '2026-09-01', 'present': false},
            {'student_id': 'stu-001', 'date': '2026-09-02', 'present': false},
            {'student_id': 'stu-001', 'date': '2026-09-03', 'present': false},
            {'student_id': 'stu-001', 'date': '2026-09-04', 'present': false},
            {'student_id': 'stu-001', 'date': '2026-09-05', 'present': true},
          ],
          'grades': [
            {'student_id': 'stu-001', 'subject': 'Matemáticas', 'period': 'Corte 1', 'value': 2.8},
            {'student_id': 'stu-001', 'subject': 'Física', 'period': 'Corte 1', 'value': 3.1},
          ],
          'observer_records': [
            {
              'student_id': 'stu-001',
              'category': 'Familiar/Entorno',
              'description': 'Falta de apoyo familiar',
              'severity': 'MEDIUM',
            },
          ],
          'absent_parent_meetings': 1,
          'warnings_this_month': 2,
        },
        widget.token,
      );
    } catch (_) {
      return const RiskReport(
        finalScore: 82,
        riskLevel: RiskLevel.red,
        triggers: ['Baja asistencia', 'Falta de acompañamiento familiar'],
        recommendedActions: ['Programar seguimiento con acudiente', 'Reforzar apoyo académico'],
        shouldNotifyImmediately: true,
      );
    }
  }

  @override
  void initState() {
    super.initState();
    _dashboardFuture = _loadDashboard();
    _riskFuture = _loadRisk();
  }

  Color _riskColor(RiskLevel level) {
    switch (level) {
      case RiskLevel.red:
        return Colors.red;
      case RiskLevel.yellow:
        return Colors.orange;
      case RiskLevel.green:
        return Colors.green;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Dashboard'),
        backgroundColor: const Color(0xFF2F59D9),
        foregroundColor: Colors.white,
      ),
      body: FutureBuilder<Map<String, dynamic>>(
        future: _dashboardFuture,
        builder: (context, dashboardSnapshot) {
          if (dashboardSnapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (dashboardSnapshot.hasError) {
            return Center(child: Text('Error: ${dashboardSnapshot.error}'));
          }

          final dashboard = dashboardSnapshot.data ?? {};
          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Card(
                  color: const Color(0xFF2F59D9),
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Hola, ${widget.user.fullName}',
                          style: const TextStyle(
                            fontSize: 28,
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Rol: ${widget.user.role}',
                          style: const TextStyle(color: Colors.white70),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: _statCard('Estudiantes', '${dashboard['total_students'] ?? 0}'),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _statCard('Activos', '${dashboard['active_students'] ?? 0}'),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                FutureBuilder<RiskReport>(
                  future: _riskFuture,
                  builder: (context, riskSnapshot) {
                    if (riskSnapshot.connectionState == ConnectionState.waiting) {
                      return const Center(child: CircularProgressIndicator());
                    }
                    if (riskSnapshot.hasError) {
                      return Center(child: Text('Riesgo no disponible: ${riskSnapshot.error}'));
                    }

                    final risk = riskSnapshot.data ??
                        const RiskReport(
                          finalScore: 0,
                          riskLevel: RiskLevel.green,
                          triggers: [],
                          recommendedActions: [],
                          shouldNotifyImmediately: false,
                        );

                    return Card(
                      color: Colors.white,
                      child: Padding(
                        padding: const EdgeInsets.all(20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                                  decoration: BoxDecoration(
                                    color: _riskColor(risk.riskLevel).withValues(alpha: 0.18),
                                    borderRadius: BorderRadius.circular(999),
                                  ),
                                  child: Text(
                                    risk.riskLevel.name.toUpperCase(),
                                    style: TextStyle(
                                      color: _riskColor(risk.riskLevel),
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ),
                                const Spacer(),
                                Text(
                                  '${risk.finalScore}/100',
                                  style: const TextStyle(
                                    fontSize: 28,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 16),
                            const Text('Disparadores', style: TextStyle(fontWeight: FontWeight.w700)),
                            ...risk.triggers.take(3).map((trigger) => Padding(
                              padding: const EdgeInsets.only(top: 8),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Icon(Icons.warning_amber_rounded, color: Colors.orange, size: 18),
                                  const SizedBox(width: 8),
                                  Expanded(child: Text(trigger)),
                                ],
                              ),
                            )),
                            const SizedBox(height: 16),
                            const Text('Acciones recomendadas', style: TextStyle(fontWeight: FontWeight.w700)),
                            ...risk.recommendedActions.take(3).map((action) => Padding(
                              padding: const EdgeInsets.only(top: 8),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Icon(Icons.check_circle_outline, color: Colors.green, size: 18),
                                  const SizedBox(width: 8),
                                  Expanded(child: Text(action)),
                                ],
                              ),
                            )),
                          ],
                        ),
                      ),
                    );
                  },
                ),
                const SizedBox(height: 18),
                const Text(
                  'Estudiantes de riesgo',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 8),
                ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: _students.length,
                  itemBuilder: (context, index) {
                    final student = _students[index];
                    final risk = student['riskLevel'] as String;
                    final color = switch (risk) {
                      'ROJO' => Colors.red,
                      'AMARILLO' => Colors.orange,
                      _ => Colors.green,
                    };

                    return Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Card(
                        child: InkWell(
                          onTap: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) => StudentDetailScreen(student: student),
                              ),
                            );
                          },
                          borderRadius: BorderRadius.circular(12),
                          child: Padding(
                            padding: const EdgeInsets.all(14),
                            child: Row(
                              children: [
                                CircleAvatar(
                                  backgroundColor: color.withOpacity(0.18),
                                  child: Text(
                                    student['name'].toString().substring(0, 1),
                                    style: TextStyle(
                                      color: color,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        student['name'],
                                        style: const TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      Text('${student['grade']} · ${student['attendance']}% asistencia'),
                                    ],
                                  ),
                                ),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                                  decoration: BoxDecoration(
                                    color: color.withOpacity(0.12),
                                    borderRadius: BorderRadius.circular(999),
                                  ),
                                  child: Text(
                                    risk,
                                    style: TextStyle(
                                      color: color,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _statCard(String label, String value) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: const TextStyle(color: Colors.grey)),
            const SizedBox(height: 8),
            Text(value, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w700)),
          ],
        ),
      ),
    );
  }
}
