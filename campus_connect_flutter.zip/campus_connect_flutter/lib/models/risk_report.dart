enum RiskLevel { green, yellow, red }

class RiskReport {
  final int finalScore;
  final RiskLevel riskLevel;
  final List<String> triggers;
  final List<String> recommendedActions;
  final bool shouldNotifyImmediately;

  const RiskReport({
    required this.finalScore,
    required this.riskLevel,
    required this.triggers,
    required this.recommendedActions,
    required this.shouldNotifyImmediately,
  });

  factory RiskReport.fromJson(Map<String, dynamic> json) {
    final level = json['risk_level'] ?? 'VERDE';
    RiskLevel parsedLevel;

    switch (level) {
      case 'ROJO':
        parsedLevel = RiskLevel.red;
        break;
      case 'AMARILLO':
        parsedLevel = RiskLevel.yellow;
        break;
      default:
        parsedLevel = RiskLevel.green;
    }

    return RiskReport(
      finalScore: (json['final_score'] as num?)?.toInt() ?? 0,
      riskLevel: parsedLevel,
      triggers: List<String>.from(json['triggers'] ?? const []),
      recommendedActions: List<String>.from(json['recommended_actions'] ?? const []),
      shouldNotifyImmediately: json['should_notify_immediately'] ?? false,
    );
  }
}
