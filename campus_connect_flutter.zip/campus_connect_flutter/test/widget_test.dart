﻿import 'package:campus_connect_flutter/main.dart';
import 'package:campus_connect_flutter/models/user.dart';
import 'package:campus_connect_flutter/screens/home_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('Campus Connect app renders the login screen', (tester) async {
    await tester.pumpWidget(const CampusConnectApp());

    expect(find.text('Campus Connect'), findsOneWidget);
    expect(find.text('Iniciar Sesión'), findsOneWidget);
  });

  testWidgets('Home dashboard shows student risk list', (tester) async {
    final user = const AppUser(
      id: 'u-1',
      email: 'teacher@campus.com',
      fullName: 'Docente Campus',
      role: 'DOCENTE',
    );

    await tester.pumpWidget(
      MaterialApp(
        home: HomeScreen(user: user, token: 'demo-token'),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('Estudiantes de riesgo'), findsOneWidget);
  });
}
