package com.example.campus_connect_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
